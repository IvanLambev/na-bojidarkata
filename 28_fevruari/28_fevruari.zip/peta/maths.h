#ifndef MATHS_H
#define MATHS_H

unsigned long long factorial(int n);

#endif /* MATHS_H */
